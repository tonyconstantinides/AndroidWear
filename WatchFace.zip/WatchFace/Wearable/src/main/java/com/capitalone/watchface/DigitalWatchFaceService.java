package com.capitalone.watchface;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.wearable.watchface.CanvasWatchFaceService;
import android.support.wearable.watchface.WatchFaceService;
import android.support.wearable.watchface.WatchFaceStyle;
import android.text.format.Time;
import android.util.Log;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.WindowInsets;

import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class DigitalWatchFaceService extends CanvasWatchFaceService {

    private static final String TAG = "DigitalWatchFaceService";

    static final String LIGHT_TYPEFACE = "fonts/proxima_nova_light.ttf";

    static final String REGULAR_TYPEFACE = "fonts/proxima_nova_reg.ttf";

    static final String BOLD_TYPEFACE = "fonts/proxima_nova_semibold.ttf";

    private static final long NORMAL_UPDATE_RATE_MS = 500;

    private static final long MUTE_UPDATE_RATE_MS = TimeUnit.MINUTES.toMillis(1);

    @Override
    public Engine onCreateEngine() {
        return new Engine();
    }

    private class Engine extends CanvasWatchFaceService.Engine {

        static final String COLON_STRING = ":";

        static final int MUTE_ALPHA = 100;

        static final int NORMAL_ALPHA = 255;

        static final int MSG_UPDATE_TIME = 0;

        long mInteractiveUpdateRateMs = NORMAL_UPDATE_RATE_MS;

        final Handler mUpdateTimeHandler = new Handler() {
            @Override
            public void handleMessage(Message message) {
                switch (message.what) {
                    case MSG_UPDATE_TIME:
                        invalidate();
                        if (shouldTimerBeRunning()) {
                            long timeMs = System.currentTimeMillis();
                            long delayMs = mInteractiveUpdateRateMs - (timeMs % mInteractiveUpdateRateMs);
                            mUpdateTimeHandler.sendEmptyMessageDelayed(MSG_UPDATE_TIME, delayMs);
                        }
                        break;
                }
            }
        };

        final BroadcastReceiver mTimeZoneReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                mTime.clear(intent.getStringExtra("time-zone"));
                mTime.setToNow();
            }
        };

        boolean mRegisteredTimeZoneReceiver = false;

        Paint mBackgroundPaint, mHourPaint, mMinutePaint, mColonPaint, mSecondPaint;

        float mColonWidth;

        boolean mMute, mLowBitAmbient, mShouldDrawColons;

        Time mTime;

        Typeface light_typeface, regular_typeface, bold_typeface;

        int mInteractiveBackgroundColor = DigitalWatchFaceUtil.COLOR_VALUE_DEFAULT_BACKGROUND;

        int mInteractiveHourDigitsColor = DigitalWatchFaceUtil.COLOR_VALUE_DEFAULT_HOUR_DIGITS;

        int mInteractiveMinuteDigitsColor = DigitalWatchFaceUtil.COLOR_VALUE_DEFAULT_MINUTE_DIGITS;

        int mInteractiveSecondColor = getResources().getColor(R.color.red);

        int mInteractiveColonColor = DigitalWatchFaceUtil.COLOR_VALUE_DEFAULT_COLON_DIGITS;

        Bitmap mBackgroundBitmap, mBackgroundBitmapAmbient, mBackgroundScaledBitmap;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);

             /* type faces */
            light_typeface = Typeface.createFromAsset(getAssets(), LIGHT_TYPEFACE);
            regular_typeface = Typeface.createFromAsset(getAssets(), REGULAR_TYPEFACE);
            bold_typeface = Typeface.createFromAsset(getAssets(), BOLD_TYPEFACE);

            setWatchFaceStyle(new WatchFaceStyle.Builder(DigitalWatchFaceService.this)
                                  .setCardPeekMode(WatchFaceStyle.PEEK_MODE_SHORT)
                                  .setBackgroundVisibility(WatchFaceStyle.BACKGROUND_VISIBILITY_INTERRUPTIVE)
                                  .setViewProtection(WatchFaceStyle.PROTECT_HOTWORD_INDICATOR | WatchFaceStyle.PROTECT_STATUS_BAR)
                                  .setStatusBarGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL)
                                  .setHotwordIndicatorGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL)
                                  .setShowSystemUiTime(false)
                                  .build());

            Resources resources = DigitalWatchFaceService.this.getResources();

            Drawable backgroundDrawable = resources.getDrawable(R.drawable.interactive_digital_bg);
            Drawable backgroundDrawableAmbient = resources.getDrawable(R.drawable.ambient_digital_bg);

            mBackgroundBitmap = ((BitmapDrawable) backgroundDrawable).getBitmap();
            mBackgroundBitmapAmbient = ((BitmapDrawable) backgroundDrawableAmbient).getBitmap();

            mBackgroundPaint = new Paint();

            mBackgroundPaint.setColor(mInteractiveBackgroundColor);

            mHourPaint = createTextPaint(mInteractiveHourDigitsColor, bold_typeface);

            mMinutePaint = createTextPaint(mInteractiveMinuteDigitsColor);

            mColonPaint = createTextPaint(mInteractiveColonColor);

            mSecondPaint = new Paint();
            mSecondPaint.setColor(mInteractiveSecondColor);
            mSecondPaint.setStrokeCap(Paint.Cap.ROUND);
            mSecondPaint.setStrokeWidth(7);
            mSecondPaint.setStyle(Paint.Style.STROKE);
            mSecondPaint.setAntiAlias(true);

            mTime = new Time();
        }

        @Override
        public void onDestroy() {
            mUpdateTimeHandler.removeMessages(MSG_UPDATE_TIME);
            super.onDestroy();
        }

        private Paint createTextPaint(int defaultInteractiveColor) {
            return createTextPaint(defaultInteractiveColor, light_typeface);
        }

        private Paint createTextPaint(int defaultInteractiveColor, Typeface typeface) {
            Paint paint = new Paint();
            paint.setColor(defaultInteractiveColor);
            paint.setTypeface(typeface);
            paint.setAntiAlias(true);
            return paint;
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            super.onVisibilityChanged(visible);

            if (visible) {
                registerReceiver();

                mTime.clear(TimeZone.getDefault().getID());
                mTime.setToNow();
            } else {
                unregisterReceiver();
            }

            updateTimer();
        }

        private void registerReceiver() {
            if (mRegisteredTimeZoneReceiver) {
                return;
            }
            mRegisteredTimeZoneReceiver = true;
            IntentFilter filter = new IntentFilter(Intent.ACTION_TIMEZONE_CHANGED);
            DigitalWatchFaceService.this.registerReceiver(mTimeZoneReceiver, filter);
        }

        private void unregisterReceiver() {
            if (!mRegisteredTimeZoneReceiver) {
                return;
            }
            mRegisteredTimeZoneReceiver = false;
            DigitalWatchFaceService.this.unregisterReceiver(mTimeZoneReceiver);
        }

        @Override
        public void onApplyWindowInsets(WindowInsets insets) {
            super.onApplyWindowInsets(insets);

            // Load resources that have alternate values for round watches.
            Resources resources = DigitalWatchFaceService.this.getResources();
            boolean isRound = insets.isRound();
            float textSize = resources.getDimension(isRound ? R.dimen.digital_text_size_round : R.dimen.digital_text_size);

            mHourPaint.setTextSize(textSize);
            mMinutePaint.setTextSize(textSize);
            mColonPaint.setTextSize(textSize);

            mColonWidth = mColonPaint.measureText(COLON_STRING);
        }

        @Override
        public void onPropertiesChanged(Bundle properties) {
            super.onPropertiesChanged(properties);

            boolean burnInProtection = properties.getBoolean(PROPERTY_BURN_IN_PROTECTION, false);
            mHourPaint.setTypeface(burnInProtection ? light_typeface : bold_typeface);

            mLowBitAmbient = properties.getBoolean(PROPERTY_LOW_BIT_AMBIENT, false);
        }

        @Override
        public void onTimeTick() {
            super.onTimeTick();
            invalidate();
        }

        @Override
        public void onAmbientModeChanged(boolean inAmbientMode) {
            super.onAmbientModeChanged(inAmbientMode);

            adjustPaintColorToCurrentMode(mBackgroundPaint, mInteractiveBackgroundColor,
                                          DigitalWatchFaceUtil.COLOR_VALUE_AMBIENT_BACKGROUND);

            adjustPaintColorToCurrentMode(mHourPaint, mInteractiveHourDigitsColor,
                                          DigitalWatchFaceUtil.COLOR_VALUE_AMBIENT_HOUR_DIGITS);

            adjustPaintColorToCurrentMode(mMinutePaint, mInteractiveMinuteDigitsColor,
                                          DigitalWatchFaceUtil.COLOR_VALUE_AMBIENT_MINUTE_DIGITS);

            adjustPaintColorToCurrentMode(mColonPaint, mInteractiveColonColor,
                                          DigitalWatchFaceUtil.COLOR_VALUE_AMBIENT_COLON_DIGITS);

            if (mLowBitAmbient) {
                boolean antiAlias = !inAmbientMode;
                mHourPaint.setAntiAlias(antiAlias);
                mMinutePaint.setAntiAlias(antiAlias);
                mSecondPaint.setAntiAlias(antiAlias);
                mColonPaint.setAntiAlias(antiAlias);
            }

            invalidate();

            updateTimer();
        }

        private void adjustPaintColorToCurrentMode(Paint paint, int interactiveColor, int ambientColor) {
            paint.setColor(isInAmbientMode() ? ambientColor : interactiveColor);
        }

        @Override
        public void onInterruptionFilterChanged(int interruptionFilter) {
            super.onInterruptionFilterChanged(interruptionFilter);

            boolean inMuteMode = interruptionFilter == WatchFaceService.INTERRUPTION_FILTER_NONE;

            setInteractiveUpdateRateMs(inMuteMode ? MUTE_UPDATE_RATE_MS : NORMAL_UPDATE_RATE_MS);

            if (mMute != inMuteMode) {
                mMute = inMuteMode;
                int alpha = inMuteMode ? MUTE_ALPHA : NORMAL_ALPHA;
                mHourPaint.setAlpha(alpha);
                mMinutePaint.setAlpha(alpha);
                mSecondPaint.setAlpha(alpha);
                mColonPaint.setAlpha(alpha);
                invalidate();
            }
        }

        public void setInteractiveUpdateRateMs(long updateRateMs) {
            if (updateRateMs == mInteractiveUpdateRateMs) {
                return;
            }
            mInteractiveUpdateRateMs = updateRateMs;

            // Stop and restart the timer so the new update rate takes effect immediately.
            if (shouldTimerBeRunning()) {
                updateTimer();
            }
        }

        private String formatTwoDigitNumber(int hour) {
            return String.format("%02d", hour);
        }

        private int convertTo12Hour(int hour) {
            int result = hour % 12;
            return (result == 0) ? 12 : result;
        }

        @Override
        public void onDraw(Canvas canvas, Rect bounds) {
            mTime.setToNow();

            int width = canvas.getWidth();
            int height = canvas.getHeight();

            // Draw the background, scaled to fit.
            if(!isInAmbientMode()) {
                mBackgroundScaledBitmap = Bitmap.createScaledBitmap(mBackgroundBitmap, width, height, true);
            }else {
                mBackgroundScaledBitmap = Bitmap.createScaledBitmap(mBackgroundBitmapAmbient, width, height,true);
            }
            canvas.drawBitmap(mBackgroundScaledBitmap, 0, 0, mBackgroundPaint);

            mShouldDrawColons = (System.currentTimeMillis() % 1000) < 500;

            int secRot = mTime.second * 6;

            // hours
            float centerY = canvas.getHeight() / 2f;
            float centerX = canvas.getWidth() / 2f;
            float y = centerY + mHourPaint.getTextSize() / 2 - 10;
            float x = centerX - (mColonWidth / 2);

            if (isInAmbientMode() || mMute || mShouldDrawColons) {
                canvas.drawText(COLON_STRING, x, y, mColonPaint);
            }

            String hourString = formatTwoDigitNumber(convertTo12Hour(mTime.hour));
            canvas.drawText(hourString, x - mHourPaint.measureText(hourString), y, mHourPaint);
            x += mColonWidth;

            // minutes
            String minuteString = formatTwoDigitNumber(mTime.minute);
            canvas.drawText(minuteString, x, y, mMinutePaint);

            //seconds
            if (!isInAmbientMode()) {
                Rect r = new Rect(bounds);
                r.inset(20, 20);
                RectF rect = new RectF(r);

                int start = -90;
                int sweep = secRot;

                canvas.drawArc(rect, start, sweep, false, mSecondPaint);
            }
        }

        /**
         * Starts the {@link #mUpdateTimeHandler} timer if it should be running and isn't currently or stops it if it shouldn't be running
         * but currently is.
         */
        private void updateTimer() {
            mUpdateTimeHandler.removeMessages(MSG_UPDATE_TIME);
            if (shouldTimerBeRunning()) {
                mUpdateTimeHandler.sendEmptyMessage(MSG_UPDATE_TIME);
            }
        }

        /**
         * Returns whether the {@link #mUpdateTimeHandler} timer should be running. The timer should only run when we're visible and in
         * interactive mode.
         */
        private boolean shouldTimerBeRunning() {
            return isVisible() && !isInAmbientMode();
        }
    }
}
