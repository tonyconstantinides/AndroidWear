package com.capitalone.watchface;

import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataMap;

import android.content.Context;
import android.graphics.Color;

public final class DigitalWatchFaceUtil {
    private static final String TAG = "DigitalWatchFaceUtil";

    /**
     * The {@link DataMap} key for {@link DigitalWatchFaceService} background color name.
     * The color name must be a {@link String} recognized by {@link Color#parseColor}.
     */
    public static final String KEY_BACKGROUND_COLOR = "BACKGROUND_COLOR";

    /**
     * The {@link DataMap} key for {@link DigitalWatchFaceService} hour digits color name.
     * The color name must be a {@link String} recognized by {@link Color#parseColor}.
     */
    public static final String KEY_HOURS_COLOR = "HOURS_COLOR";

    /**
     * The {@link DataMap} key for {@link DigitalWatchFaceService} minute digits color name.
     * The color name must be a {@link String} recognized by {@link Color#parseColor}.
     */
    public static final String KEY_MINUTES_COLOR = "MINUTES_COLOR";

    /**
     * The {@link DataMap} key for {@link DigitalWatchFaceService} second digits color name.
     * The color name must be a {@link String} recognized by {@link Color#parseColor}.
     */
    public static final String KEY_SECONDS_COLOR = "SECONDS_COLOR";

    /**
     * The path for the {@link DataItem} containing {@link DigitalWatchFaceService} configuration.
     */
    public static final String PATH_WITH_FEATURE = "/watch_face_config/Digital";

    /**
     * Name of the default interactive mode background color and the ambient mode background color.
     */
    public static final String COLOR_NAME_AMBIENT_BACKGROUND = "Black";
    public static final int COLOR_VALUE_AMBIENT_BACKGROUND =
            parseColor(COLOR_NAME_AMBIENT_BACKGROUND);

    public static final String COLOR_NAME_DEFAULT_BACKGROUND = "White";
    public static final int COLOR_VALUE_DEFAULT_BACKGROUND =
        parseColor(COLOR_NAME_DEFAULT_BACKGROUND);

    /**
     * Name of the default interactive mode hour digits color and the ambient mode hour digits
     * color.
     */
    public static final String COLOR_NAME_AMBIENT_HOUR_DIGITS = "White";
    public static final int COLOR_VALUE_AMBIENT_HOUR_DIGITS =
            parseColor(COLOR_NAME_AMBIENT_HOUR_DIGITS);

    public static final String COLOR_NAME_DEFAULT_HOUR_DIGITS = "Black";
    public static final int COLOR_VALUE_DEFAULT_HOUR_DIGITS =
        parseColor(COLOR_NAME_DEFAULT_HOUR_DIGITS);

    /**
     * Name of the default interactive mode minute digits color and the ambient mode minute digits
     * color.
     */
    public static final String COLOR_NAME_DEFAULT_MINUTE_DIGITS = "Black";
    public static final int COLOR_VALUE_DEFAULT_MINUTE_DIGITS =
            parseColor(COLOR_NAME_DEFAULT_MINUTE_DIGITS);

    public static final String COLOR_NAME_AMBIENT_MINUTE_DIGITS = "White";
    public static final int COLOR_VALUE_AMBIENT_MINUTE_DIGITS =
        parseColor(COLOR_NAME_AMBIENT_MINUTE_DIGITS);

    /**
     * Name of the default interactive mode colon digits color and the ambient mode colon digits
     * color.
     */
    public static final String COLOR_NAME_DEFAULT_COLON_DIGITS = "Grey";
    public static final int COLOR_VALUE_DEFAULT_COLON_DIGITS =
        parseColor(COLOR_NAME_DEFAULT_COLON_DIGITS);

    public static final String COLOR_NAME_AMBIENT_COLON_DIGITS = "Grey";
    public static final int COLOR_VALUE_AMBIENT_COLON_DIGITS =
        parseColor(COLOR_NAME_AMBIENT_COLON_DIGITS);

    /**
     * Name of the default interactive mode second color and the ambient mode second color.
     */
    public static final String COLOR_NAME_AMBIENT_SECONDS = "White";
    public static final int COLOR_VALUE_AMBIENT_SECONDS =
        parseColor(COLOR_NAME_AMBIENT_SECONDS);

    public static final String COLOR_NAME_DEFAULT_SECONDS = "Red";
    public static final int COLOR_VALUE_DEFAULT_SECONDS =
        parseColor(COLOR_NAME_DEFAULT_SECONDS);


    /**
     * Callback interface to perform an action with the current config {@link DataMap} for
     * {@link DigitalWatchFaceService}.
     */
    public interface FetchConfigDataMapCallback {
        /**
         * Callback invoked with the current config {@link DataMap} for
         * {@link DigitalWatchFaceService}.
         */
        void onConfigDataMapFetched(DataMap config);
    }

    private static int parseColor(String colorName) {
        return Color.parseColor(colorName.toLowerCase());
    }

    private DigitalWatchFaceUtil() {}
}
